# Proyecto de Lenguajes de programacion

## Para compilar en consola

ubicarse dentro de la carpeta donde se hayan los archivos, luego compilar el archivo GUI:

```
cd carpeta
ruby GUI.rb
```

## Para eclipse
#### importar por carpeta
crear una carpeta con nombre "ProyectoLenguajes" e ingresarla dentro del directorio de tu workspace, luego

> import > Existing Projects in to Workspace > select root directory > seleccionar la carpeta en el workspace

#### importar por zip
crear un zip con los todos archivos del repositorio con el nombre de "ProyectoLenguajes" luego:

> import > Existing Projects in to Workspace > select archive file > seleccionar el zip

## Si no funciona lo demas xD
copiar archivos txt y pl a tu proyecto, despues copia el codigo necesario para sustituirlo por el de tu proyecto

## Grafico

<a href="https://imgbb.com/"><img src="https://i.ibb.co/Qf8pfMT/grafico.png" alt="grafico" border="0"></a>